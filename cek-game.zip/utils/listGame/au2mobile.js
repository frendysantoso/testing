const dataAU2mobile = {
   data: [
      {
         id: 5000,
         name: 'AU2 Mobile',
         slug: 'au2-mobile',
         provider: 'au2mobile',
         isZone: false,
      },
   ],
};

module.exports = dataAU2mobile;
