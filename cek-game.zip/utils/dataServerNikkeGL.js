const dataServerNikkeGL = [
   {
      id: '1',
      name: 'KR',
      region: 'KR',
      zoneId: 83,
   },
   {
      id: '2',
      name: 'JP',
      region: 'JP',
      zoneId: '81',
   },
   {
      id: '3',
      name: 'GLOBAL',
      region: 'GLOBAL',
      zoneId: '84',
   },
   {
      id: '4',
      name: 'SEA',
      region: 'SEA',
      zoneId: '85',
   },
   {
      id: '5',
      name: 'NA',
      region: 'NA',
      zoneId: '82',
   },
];

module.exports = dataServerNikkeGL;
